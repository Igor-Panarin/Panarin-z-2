#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define RESULT 1

void AutoTest (int );
